from flask import Flask,render_template,request,url_for
import mysql.connector
import os 
app=Flask(__name__)

@app.route ('/home')
def home():
    return render_template ("education.html")

@app.route('/contact')
def contact():
    return render_template("contact.html")

@app.route('/')
def login():
    return render_template("login.html")

@app.route('/', methods=['POST'])
def login1():
    a= request.form['nm']
    b= request.form['ps']
    if request.method == 'POST':
       mydb = mysql.connector.connect(
          host="localhost",
          user="root",
          password="",
          database="project",
          use_unicode=True,
          charset='ascii'
      )
    
    mycursor = mydb.cursor()
    if a=="admin" and b=="admin":
        return render_template("admin.html")
    else:
            sql = "select * from register where username='"+a+"' and password='"+b+"'"
            mycursor.execute(sql)
            myresult = mycursor.fetchone()
    
            if myresult:   
              return render_template("user.html")
            else:      
              return render_template("login.html")
    

@app.route('/contact', methods=['POST'])
def contact1():
    a= request.form['nam']
    b= request.form['em']
    c = request.form['area'] 
    if request.method == 'POST':
     mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="project",
            use_unicode=True,
            charset='ascii'
        )
     mycursor = mydb.cursor()
     sql = "INSERT INTO contact values('"+a+"','"+b+"','"+c+"')"
     mycursor.execute(sql)
     mydb.commit()
     return ('sent Successfully')

@app.route('/about')
def about():
    return render_template("about.html")

@app.route('/course')
def course():
    return render_template("course.html")

@app.route('/register')
def register():
    return render_template("register.html")

@app.route('/register', methods=['POST'])
def register1():
    a= request.form['fir']
    b= request.form['las']
    c = request.form['phone']
    d = request.form['mail']
    e = request.form['pass']
    if request.method == 'POST':
     mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="project",
            use_unicode=True,
            charset='ascii'
        )
     mycursor = mydb.cursor()
     sql = "INSERT INTO register values('"+a+"','"+b+"','"+c+"','"+d+"','"+e+"')"
     mycursor.execute(sql)
     mydb.commit()
     return ('Register Successfully')

@app.route('/admin')
def admin1():
    return render_template("admin.html")
   
@app.route('/admin', methods=['POST', 'GET'])
def admin():
 if request.method =='POST':
  if request.form['btn'] == 'Insert':
    user = request.form['nm']
    user1 = request.form['nm1']
    user2 = request.form['nm2']
    user3 = request.form['nm3']
    user4 = request.form['nm4']
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="",
        database="project",
        use_unicode=True,
        charset='ascii'
    )
    mycursor = mydb.cursor()
    sql = "INSERT INTO admin values('"+user+"','"+user1+"','"+user2+"','"+user3+"','"+user4+"')"
    mycursor.execute(sql)
    mydb.commit()
    return ('inserted Successfully')
  if request.form['btn'] == 'Delete':
      user = request.form['nm']
      mydb = mysql.connector.connect(
          host="localhost",
          user="root",
          passwd="",
          database="project",
          use_unicode=True,
          charset='ascii'
      )
      mycursor = mydb.cursor()
      sql = "delete from admin where course='"+user+"'"
      mycursor.execute(sql)
      mydb.commit()
      return ('deleted Successfully')
  if request.form['btn'] == 'Update':
      user = request.form['nm']
      user1 = request.form['nm1']
      user2 = request.form['nm2']
      user3 = request.form['nm3']
      user4 = request.form['nm4']
      mydb = mysql.connector.connect(
          host="localhost",
          user="root",
          passwd="",
          database="project",
          use_unicode=True,
          charset='ascii'
      )
      mycursor = mydb.cursor()
      sql = "Update admin SET description='"+user1+"',fees='"+user2+"',time='"+user3+"',certificate='"+user4+"' WHERE course ='"+user+"'"
      mycursor.execute(sql)
      mydb.commit()
      return ('Updated Successfully')
  if request.form['btn'] == 'Select':
      user = request.form['nm']
      mydb = mysql.connector.connect(
          host="localhost",
          user="root",
          passwd="",
          database="project",
          use_unicode=True,
          charset='ascii'
      )
      mycursor = mydb.cursor()
      sql = "select * from admin where course='"+user+"'"
      mycursor.execute(sql)
      myresult = mycursor.fetchall()
      return render_template("admin.html",data=myresult)


@app.route('/student')
def student1():
  return render_template("student.html")


UPLOAD_FOLDER = 'static' 
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/student', methods=['POST', 'GET'])
def student():
 if request.method =='POST':
   if request.form['btn1'] == 'Insert':
       user = request.form['sn']
       user1 = request.form['cs']
       user2 = request.form['tm']
       user3 = request.form['ap']
       file1 = request.files['cc']
       file1.save(os.path.join(UPLOAD_FOLDER, file1.filename))

       mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="",
                database="project"
            )
       mycursor = mydb.cursor()
       sql = "INSERT INTO student (name, course, timing, amount, photo) VALUES (%s, %s, %s, %s, %s)"
       val = (user, user1, user2, user3, file1.filename)
       mycursor.execute(sql, val)
       mydb.commit()
       return 'Inserted Successfully'
   if request.form['btn1'] == 'Delete':
      user = request.form['sn']
      mydb = mysql.connector.connect(
          host="localhost",
          user="root",
          passwd="",
          database="project",
          use_unicode=True,
          charset='ascii'
      )
      mycursor = mydb.cursor()
      sql = "delete from student where name='"+user+"'"
      mycursor.execute(sql)
      mydb.commit()
      return ('deleted Successfully')
   if request.form['btn1'] == 'Update':
      user = request.form['sn']
      user1 = request.form['cs']
      user2 = request.form['tm']
      user3 = request.form['ap']
      file1 = request.files['cc']
      file1.save(os.path.join(UPLOAD_FOLDER, file1.filename))
      
      mydb = mysql.connector.connect(
          host="localhost",
          user="root",
          passwd="",
          database="project",
          use_unicode=True,
          charset='ascii'
      )
      mycursor = mydb.cursor()
      sql = "Update student SET course='"+user1+"',timing='"+user2+"',amount='"+user3+"',photo='"+file1.filename+"' WHERE name ='"+user+"'"
      mycursor.execute(sql)
      mydb.commit()
      return ('Updated Successfully')
   if request.form['btn1'] == 'Select':
      user = request.form['cs']
      mydb = mysql.connector.connect(
          host="localhost",
          user="root",
          passwd="",
          database="project",
          use_unicode=True,
          charset='ascii'
      )
      mycursor = mydb.cursor()
      sql = "select * from student where course='"+user+"'"
      mycursor.execute(sql)
      myresult = mycursor.fetchall()
      return render_template("student.html",data1=myresult)

 


UPLOAD_FOLDER = 'static' 
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
@app.route('/staff')
def staff1():
  return render_template("staff.html")

@app.route('/staff', methods=['POST', 'GET'])
def stafff():
  if request.method == 'POST':
    if request.form['btn'] == 'Insert':
            user1 = request.form['sna']
            user2 = request.form['crs']
            user3 = request.form['ql']
            user4 = request.form['cnt']
            file = request.files['pt']
            file.save(os.path.join(UPLOAD_FOLDER, file.filename))

            mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="",
                database="project"
            )
            mycursor = mydb.cursor()
            sql = "INSERT INTO staff (name, course, qualification, contact, photo) VALUES (%s, %s, %s, %s, %s)"
            val = (user1, user2, user3, user4, file.filename)
            mycursor.execute(sql, val)
            mydb.commit()

            return 'Inserted Successfully'
    



  if request.form['btn'] == 'Delete':
      user = request.form['sna']
      mydb = mysql.connector.connect(
          host="localhost",
          user="root",
          passwd="",
          database="project",
          use_unicode=True,
          charset='ascii'
      )
      mycursor = mydb.cursor()
      sql = "delete from staff where name='"+user+"'"
      mycursor.execute(sql)
      mydb.commit()
      return ('deleted Successfully')
  if request.form['btn'] == 'Update':
      user = request.form['sna']
      user1 = request.form['crs']
      user2 = request.form['ql']
      user3 = request.form['cnt']
      file = request.files['pt']
      file.save(os.path.join(UPLOAD_FOLDER, file.filename))
      mydb = mysql.connector.connect(
          host="localhost",
          user="root",
          passwd="",
          database="project",
          use_unicode=True,
          charset='ascii'
      )
      mycursor = mydb.cursor()
      sql = "Update staff SET course='"+user1+"',qualification='"+user2+"',contact='"+user3+"',photo='"+file.filename+"' WHERE name ='"+user+"'"
      mycursor.execute(sql)
      mydb.commit()
      return ('Updated Successfully')
  if request.form['btn'] == 'Select':
      user = request.form['crs']
      mydb = mysql.connector.connect(
          host="localhost",
          user="root",
          passwd="",
          database="project",
          use_unicode=True,
          charset='ascii'
      )
      mycursor = mydb.cursor()
      sql = "select * from staff where course='"+user+"'"
      mycursor.execute(sql)
      myresult = mycursor.fetchall()
      return render_template("staff.html",data2=myresult)

if __name__=='__main__':
 app.run()